class FactorialSemCache {
  // Função recursiva para calcular o fatorial sem cache
  factorial(n: number): number {
    if (n === 0 || n === 1) {
      return 1;
    }
    return n * this.factorial(n - 1);
  }

  // Função para medir o tempo de execução
  tempoFactorial(n: number, reps: number): void {
    console.time(`Tempo de execução sem cache`);
    for (let i = 0; i < reps; i++) {
      this.factorial(n);
    }
    console.timeEnd(`Tempo de execução sem cache`);
  }
}

class FactorialComCache {
  // Cache para armazenar os resultados de chamadas anteriores
  cache: { [key: number]: number } = {};

  // Função recursiva para calcular o fatorial com cache
  factorial(n: number): number {
    if (this.cache[n] !== undefined) {
      return this.cache[n];
    }
    if (n === 0 || n === 1) {
      return 1;
    }
    const result = n * this.factorial(n - 1);
    this.cache[n] = result;
    return result;
  }

  // Função para medir o tempo de execução
  tempoFactorial(n: number, reps: number): void {
    console.time(`Tempo de execução com cache`);
    for (let i = 0; i < reps; i++) {
      this.factorial(n);
    }
    console.timeEnd(`Tempo de execução com cache`);
  }
}

const factSemCache = new FactorialSemCache();
factSemCache.tempoFactorial(20, 1);
factSemCache.tempoFactorial(20, 100);
factSemCache.tempoFactorial(20, 1000);
factSemCache.tempoFactorial(20, 10000);
factSemCache.tempoFactorial(20, 100000);
factSemCache.tempoFactorial(20, 1000000);
factSemCache.tempoFactorial(20, 10000000);
console.log("-------------------------------------");
const factComCache = new FactorialComCache();
factComCache.tempoFactorial(20, 1);
factComCache.tempoFactorial(20, 100);
factComCache.tempoFactorial(20, 1000);
factComCache.tempoFactorial(20, 10000);
factComCache.tempoFactorial(20, 100000);
factComCache.tempoFactorial(20, 1000000);
